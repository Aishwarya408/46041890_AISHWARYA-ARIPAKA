package arrays;
import java.util.*;
public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt(); // no of elements in array
		int i=0;
		int[] a=new int[n];
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println(" ************ ");
		Exercise3 obj=new Exercise3();
		a=obj.getSorted(a);
		System.out.println("returned");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}
		
	}

	public int[] getSorted(int[] a)
	{
		int i=0;
		String str;
		StringBuffer rev;
		for(i=0;i<a.length;i++)
		{
			str=Integer.toString(a[i]);
			rev=new StringBuffer(str);
			a[i]=Integer.parseInt(new String(rev.reverse()));
		}
		

		System.out.println("reversed array"); //reversed
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}	
		
		Arrays.sort(a);							
		
		return a;
	}
}
