package lab3;
import java.util.*;
public class Exercise3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		Exercise3 obj=new Exercise3(); 
		System.out.println(obj.alterString(str));

	}
	
	public String alterString(String str)
	{
		char c;
		String s="";
		for(int i=0;i<str.length();i++)
		{
			c=str.charAt(i);
			if(c=='a'||c=='e'||c=='i'||c=='o'||c=='u')
			{
				s=s+c+"";
			}
			else
			{
				s=s+(char)(c+1)+"";
			}
		}
		
		return s;
		
	}

}
