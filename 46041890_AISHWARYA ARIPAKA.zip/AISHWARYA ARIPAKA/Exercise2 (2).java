package lab3;
import java.util.*;
public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		
		
		Exercise2 obj=new Exercise2();
		
		System.out.println(str+obj.getImage(str));
	}
	
	public String getImage(String str)
	{
		StringBuffer sb=new StringBuffer(str);
		sb.append("|");
		String piped=new String(sb.reverse());
		return piped;
	}
}
