package lab3;
import java.util.*;
public class Exercise4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		Exercise4 obj=new Exercise4();
		System.out.println(obj.modifyNumber(n));

	}
	
	public int modifyNumber(int n)
	{
		int i;
		char c;
		String num=Integer.toString(n);
		num=num+num.charAt(0);
		StringBuffer sb=new StringBuffer("");
		for(i=0;i<num.length()-1;i++)
		{
			
			//System.out.println(Math.abs((int)(num.charAt(i)-(int)num.charAt(i+1))));
			sb.append(Math.abs((int)(num.charAt(i)-(int)num.charAt(i+1))));
			
		}
		i=Integer.parseInt(new String(sb));
		return i;
	}

}
