package lab3;
import java.util.*;
public class StrBufferr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String c;
		StringTokenizer st=new StringTokenizer(str);
		
	/*	while(st.hasMoreTokens())
		{
			System.out.println(st.nextToken(","));
		}*/
		
		
		while(st.hasMoreTokens())
		{
			c=st.nextToken();
			System.out.println(c);
			sum=sum+Integer.parseInt(c);
		/*	System.out.println(st.nextToken());
			System.out.println(st.nextElement());
			System.out.println(st.nextToken());*/
		}
		System.out.println(" total : "+sum);    
	}

}
