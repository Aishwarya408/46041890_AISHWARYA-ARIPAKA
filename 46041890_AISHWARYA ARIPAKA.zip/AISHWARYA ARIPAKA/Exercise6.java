package flowcontrol;
import java.util.*;
public class Exercise6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise6 obj=new Exercise6();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		System.out.println(obj.calculateDifference(n));

	}

	public int calculateDifference(int n)
	{
		int sum=0;
		int x=0,y=0;
		for(int i=0;i<=n;i++)
		{
			x=x+(int)Math.pow(i, 2);
			y=y+i;
		}
		y=(int)Math.pow(y, 2);
		sum=x-y;
		return sum;
	}
}
