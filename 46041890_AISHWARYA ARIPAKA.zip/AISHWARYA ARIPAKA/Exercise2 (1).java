package arrays;
import java.util.*;
public class Exercise2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String str=sc.nextLine();
		String[] str_arr=new String[str.length()] ;
		
		str_arr=str.split(" ");
		
		Exercise2 obj=new Exercise2();
		str_arr=obj.method(str_arr);
		for(int i=0;i<str_arr.length;i++)
		{
			System.out.println(str_arr[i]);
		}
		
	}
	public String[] method(String[] str_arr)
	{
		Arrays.sort(str_arr);
		int n=0,i=0;
		n=(str_arr.length%2==0)?(str_arr.length/2):(str_arr.length/2)+1;
		System.out.println(n);
		for(i=0;i<n;i++)
		{
			str_arr[i]=str_arr[i].toUpperCase();
		}
		for(i=n;i<str_arr.length;i++)
		{
			str_arr[i]=str_arr[i].toLowerCase();
		}
		return str_arr;
	}
	
}
