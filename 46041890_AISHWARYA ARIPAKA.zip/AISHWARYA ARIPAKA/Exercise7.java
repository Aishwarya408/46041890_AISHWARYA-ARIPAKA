package flowcontrol;
import java.util.*;
public class Exercise7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Exercise7 obj=new Exercise7();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(obj.checkNumber(n))
		{
			System.out.println(n+" is a increasing number");
		}
		else
		{
			System.out.println(n+" is not a increasing number");
		}
	}

	public boolean checkNumber(int n)
	{
		int y=0,r=0;
		y=n%10;
		while(n!=0)
		{
			r=n%10;
			if(y>=r)
			{
				y=r;				
			}
			else
			{
				return false;
			}
			n=n/10;
		}
		return true;
	}
}
