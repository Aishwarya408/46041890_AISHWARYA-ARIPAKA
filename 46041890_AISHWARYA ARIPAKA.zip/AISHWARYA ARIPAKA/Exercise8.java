package flowcontrol;
import java.util.*;
public class Exercise8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Exercise8 obj=new Exercise8();
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		if(obj.checkNumber(n))
		{
			System.out.println(n+" is a power of 2");
		}
		else
		{
			System.out.println(n+" is not a power of 2");
		}
	}
	
	public boolean checkNumber(int n)
	{
		for(int i=0;(int)Math.pow(2,i)<=n;i++)
		{
			if((int)Math.pow(2,i)==n)
			{
				return true;
			}
		}
		return false;
	}

}
