package arrays;
import java.util.*;
public class Exercise1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		Exercise1 obj=new Exercise1();
		int n=sc.nextInt();   //no of elements in a an array
		int a[]=new int[n];
		for(int i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		System.out.println(obj.getSecondSmallest(a));
	}
	
	public int getSecondSmallest(int[] a)
	{
		Arrays.sort(a);
		return a[1];
	}
}
