package arrays;

import java.util.Arrays;
import java.util.Scanner;

public class Exercise4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt(); // no of elements in array
		int i=0;
		int[] a=new int[n];
		for(i=0;i<n;i++)
		{
			a[i]=sc.nextInt();
		}
		
		Exercise4 obj=new Exercise4();
		a=obj.modifyArray(a);
		System.out.println("Removed duplicates");
		for(i=0;i<a.length;i++)
		{
			System.out.println(a[i]);
		}

	}
	
	public int[] modifyArray(int[] a)
	{
		int count=0,i;
		int[] array=new int[a.length];
		Arrays.sort(a);
		for(i=0;i<=a.length;i++)
		{
			if(i!=(a.length-1))
			{
				System.out.println(i+" "+(a.length-1));
				System.out.println(i+" "+(i+1));
				if(a[i]!=a[i+1])
				{
					array[count]=a[i];
					count++;
				}
			}
			else
			{
				if(a[i-1]!=a[i])
				{
					array[count]=a[i];
					break;
				}
			}
			

		}
		System.out.println("Removed duplicates");
		for(i=0;i<=count;i++)
		{
			System.out.println(array[i]);
		}
		return array;
	}

}
